import {
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
  SlashCommandBuilder,
} from "discord.js";

import { fetchCharacter } from "../services/rucoy/character.service.js";

export default {
  data: new SlashCommandBuilder()
    .setName("character")
    .setDescription("Mostra informações de um personagem do Rucoy")
    .addStringOption(opt =>
      opt
        .setName("name")
        .setDescription("Nome do personagem")
        .setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    const name = interaction.options.getString("name", true);

    await interaction.deferReply({
      flags: MessageFlags.Ephemeral,
    });

    let character;
    try {
      character = await fetchCharacter(name);
    } catch {
      await interaction.editReply(
        "❌ Personagem não encontrado."
      );
      return;
    }

    // ===== EMBED 1 — INFO =====
    const infoEmbed = new EmbedBuilder()
      .setTitle(`👤 ${character.name}`)
      .setColor(0x00ff99)
      .addFields(
        { name: "Level", value: String(character.level), inline: true },
        {
          name: "Status",
          value: character.online ? "🟢 Online" : "⚫ Offline",
          inline: true,
        },
        {
          name: "Supporter",
          value: character.supporter ? "✅ Sim" : "❌ Não",
          inline: true,
        },
      );

    if (character.guild) {
      infoEmbed.addFields({
        name: "Guild",
        value: character.guild.name,
        inline: true,
      });
    }

    if (character.title) {
      infoEmbed.addFields({
        name: "Title",
        value: `${character.title.name} (${character.title.rarity})`,
        inline: true,
      });
    }

    if (character.born) {
      infoEmbed.addFields({
        name: "Born",
        value: character.born,
        inline: true,
      });
    }

    // ===== EMBED 2 — RECENT ACTIVITY =====
    const activityEmbed = new EmbedBuilder()
      .setTitle("⚔️ Recent Kills & Deaths")
      .setColor(0xff5555)
      .setDescription(
        character.recentActivity.length
          ? character.recentActivity.join("\n")
          : "Nenhuma atividade recente."
      );

    await interaction.editReply({
      embeds: [infoEmbed, activityEmbed],
    });
  },
};
