import {
  ChatInputCommandInteraction,
  EmbedBuilder,
  MessageFlags,
  SlashCommandBuilder,
} from "discord.js";

import { fetchGuildMembers } from "../services/rucoy/guild.service.js"

// cargos que podem executar o comando
const ALLOWED_ROLE_IDS = [
  "1207024850925912115", // dev
  "1457465099215179837", // VirtueBetaTeste
];

export default {
  data: new SlashCommandBuilder()
    .setName("guild")
    .setDescription("Mostra informações de uma guild do Rucoy Online")
    .addStringOption(option =>
      option
        .setName("name")
        .setDescription("Nome da guild")
        .setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    // ===== PERMISSÃO =====
    const member = interaction.guild?.members.cache.get(
      interaction.user.id
    );
    if (!member) return;

    const hasRole = member.roles.cache.some(role =>
      ALLOWED_ROLE_IDS.includes(role.id)
    );

    if (!hasRole) {
      await interaction.reply({
        content:
          "Calma lá amiguinho, só o kuuhaku pode usar esse comando... SAFADINHO 😈",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const guildName = interaction.options.getString("name", true);

    await interaction.deferReply({
      flags: MessageFlags.Ephemeral,
    });

    // ===== BUSCA =====
    let members;
    try {
      members = await fetchGuildMembers(guildName);
    } catch {
      await interaction.editReply("❌ Erro ao buscar dados da guild.");
      return;
    }

    if (!members.length) {
      await interaction.editReply(
        "❌ Guild não encontrada ou sem membros."
      );
      return;
    }

    // ===== PROCESSAMENTO =====
    const onlineMembers = members.filter(m => m.online);

    const allMembersText = members
      .map(
        m =>
          `• **${m.name}** (Lv ${m.level})` +
          (m.leader ? " 👑" : "") +
          (m.online ? " 🟢" : "")
      )
      .join("\n");

    const onlineMembersText =
      onlineMembers.length > 0
        ? onlineMembers
            .map(
              m =>
                `• **${m.name}** (Lv ${m.level})` +
                (m.leader ? " 👑" : "")
            )
            .join("\n")
        : "Nenhum membro online no momento.";

    // ===== EMBED 1 — TODOS =====
    const allMembersEmbed = new EmbedBuilder()
      .setTitle(`🏰 ${guildName} — Todos os Membros`)
      .setDescription(allMembersText)
      .setColor(0x00ff99)
      .setFooter({
        text: `Total: ${members.length} membros`,
      });

    // ===== EMBED 2 — ONLINE =====
    const onlineEmbed = new EmbedBuilder()
      .setTitle(`🟢 ${guildName} — Membros Online`)
      .setDescription(onlineMembersText)
      .setColor(0x00ff99)
      .setFooter({
        text: `Online: ${onlineMembers.length}`,
      });

    await interaction.editReply({
      embeds: [allMembersEmbed, onlineEmbed],
    });
  },
};
