import {
  ChatInputCommandInteraction,
  SlashCommandBuilder,
  TextChannel,
} from "discord.js";

import { startGuildSpy } from "../spy/guild.spy.js";

export default {
  data: new SlashCommandBuilder()
    .setName("guildspy")
    .setDescription("Inicia o monitoramento de uma guild")
    .addStringOption(opt =>
      opt.setName("guild")
        .setDescription("Nome da guild")
        .setRequired(true)
    )
    .addChannelOption(opt =>
      opt.setName("channel")
        .setDescription("Canal para logs")
        .setRequired(true)
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    const guildName = interaction.options.getString("guild", true);
    const channel = interaction.options.getChannel("channel", true);

    if (!(channel instanceof TextChannel)) {
      await interaction.reply("❌ Canal inválido.");
      return;
    }

    await interaction.reply({
      content: `🕵️ Guild Spy iniciado para **${guildName}**`,
      ephemeral: true,
    });

    startGuildSpy(guildName, channel);
  },
};
