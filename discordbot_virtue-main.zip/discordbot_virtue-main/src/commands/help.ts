import { ChatInputCommandInteraction, EmbedBuilder, MessageFlags, SlashCommandBuilder } from 'discord.js';


// cargos que podem executar o commando
const ALLOWED_ROLE_IDS = [
  '1207024850925912115', // dev
  '1457465099215179837' // VirtueBetaTeste 
//   '1207026614119039087', // virtue
];


export default {
    // Cria o Slash Commanda
	data: new SlashCommandBuilder()
		.setName('help')
		.setDescription('Como usar os comandos do Bot'),

    // Corpo da Resposta do Command
	async execute(interaction: ChatInputCommandInteraction) {
        
        // Verificar Permissao de quem pode usar o command

        // Pega id do Membro que executou o Command
        const member = interaction.guild?.members.cache.get(interaction.user.id);

        // Verifica se membro esta no servidor
        if(!member) return;

        // Verifica se o membro tem o cargo para executar  o commando
        const hasRole = member.roles.cache.some(role => ALLOWED_ROLE_IDS.includes(role.id));

        // Verifica se o user nao tem a tag. e manda mensagem se aviso se nao tiver
        if(!hasRole){
            await interaction.reply(
                {
                    content: `Calma Lá amiguinho so o kuuhaku pode usar esse comando... SAFADINHO`,
                    flags: MessageFlags.Ephemeral
                }
            );
            return;
        }

        // Criando a Embed
        const embed = new EmbedBuilder()
        .setTitle("Commandos Bot da Virtue")
        .setDescription("Como usar os commandos do Bot da  Virtue")
        .setColor(0x00ff99)
        .setFooter({
            text: "Criado por Kuuhaku <3"
        })
        .setAuthor({
            name: "Virtue Bot",
        })
        .addFields(
            {
                name: "/help",
                value: " - Mostra todos os comandos disponiveis e como usalos",
                inline: false
            },
            {
                name: "/submit",
                value:
                " - Comando Para Participar do Rank Interno Da Virtue\n" + 
                " - Coloque os Seus Requesitos, nos Lugares Referentes (Melee, Magic Etc)\n" +
                " - Mande uma foto em qualquer lugar no discord e copie o link,E Entao mande o link no comando em proof.\n",
                inline: false
            }
        )
    

        await interaction.reply(
            {
                embeds: [embed],
                // ephemeral: true forma atinga
                flags: MessageFlags.Ephemeral
            }
        );

	},
};




