import { ChatInputCommandInteraction, EmbedBuilder, SlashCommandBuilder } from 'discord.js';
import { getRecentMobEvents } from '../storage/mob-history.store.js';

export default {
    data: new SlashCommandBuilder()
        .setName('mobwins')
        .setDescription('Mostra os últimos players que perderam XP (tomaram mob)')
        .addIntegerOption(opt => opt.setName('limit').setDescription('Quantos eventos mostrar (max 50)').setMinValue(1).setMaxValue(50)),

    async execute(interaction: ChatInputCommandInteraction) {
        const limit = interaction.options.getInteger('limit') ?? 25;
        const entries = await getRecentMobEvents(limit);

        if (entries.length === 0) {
            await interaction.reply({ content: 'Nenhum evento de mob registrado ainda.', ephemeral: true });
            return;
        }

        const embed = new EmbedBuilder()
            .setTitle('⚔️ Últimos mob wins')
            .setColor(0xff0000)
            .setTimestamp();

        // agrupa por linha
        const lines = entries.map((e, i) => {
            const s = `${i + 1}. **${e.name}** — perdeu **${e.event.lost.toLocaleString()} XP** (antes: ${e.event.before.toLocaleString()} → agora: ${e.event.after.toLocaleString()}) — ${new Date(e.event.date).toLocaleString()}`;
            return s;
        });

        // Discord embed limite de tamanho; vamos fatiar em caso de muitos
        const chunk = lines.join('\n');
        if (chunk.length > 4096) {
            await interaction.reply({ content: lines.join('\n').slice(0, 4000) + '\n... (truncado)', ephemeral: true });
            return;
        }

        embed.setDescription(chunk);

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};