import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';

export default {
	data: new SlashCommandBuilder()
		.setName('ping')
		.setDescription('Mostra o ping do bot'),

	async execute(interaction: ChatInputCommandInteraction) {
		await interaction.reply(
			`🏓 Pong! ${interaction.client.ws.ping}ms`
		);
	},
};
