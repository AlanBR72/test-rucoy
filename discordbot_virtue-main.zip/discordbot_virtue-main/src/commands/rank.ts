import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChatInputCommandInteraction, SlashCommandBuilder, TextChannel } from 'discord.js';
import { PlayerData, players } from '../data/players.js';
import { savePlayers } from '../data/storage.js';

// ID do canal de verificação
const VERIFICATION_CHANNEL_ID = '1454961279339860010';
// cargos que podem executar o commando
const ALLOWED_ROLE_IDS = [
  '1207024850925912115', // dev
  '1207026614119039087', // virtue
];

export default {
	data: new SlashCommandBuilder()
		.setName('submit')
		.setDescription('Enviar stats da sua conta')
		.addIntegerOption(opt => opt.setName('level').setDescription('Level').setRequired(true))
		.addIntegerOption(opt => opt.setName('melee').setDescription('Melee').setRequired(true))
		.addIntegerOption(opt => opt.setName('pally').setDescription('Pally').setRequired(true))
		.addIntegerOption(opt => opt.setName('mage').setDescription('Mage').setRequired(true))
		.addIntegerOption(opt => opt.setName('defense').setDescription('Defense').setRequired(true))
		.addStringOption(opt => opt.setName('proof').setDescription('Link da imagem de prova').setRequired(true)),

	async execute(interaction: ChatInputCommandInteraction) {

		// Verifica permissões
		const member = interaction.guild?.members.cache.get(interaction.user.id);
		if (!member) return;

		const hasRole = member.roles.cache.some(role => ALLOWED_ROLE_IDS.includes(role.id));
		if (!hasRole) {
			await interaction.reply({
				content: '❌ Você não tem permissão para usar este comando.',
				ephemeral: true
			});
			return;
		}
		
		const userId = interaction.user.id;
		const stats = {
			level: interaction.options.getInteger('level', true),
			melee: interaction.options.getInteger('melee', true),
			pally: interaction.options.getInteger('pally', true),
			mage: interaction.options.getInteger('mage', true),
			defense: interaction.options.getInteger('defense', true),
		};
		const proofUrl = interaction.options.getString('proof', true);
		const displayName = interaction.guild?.members.cache.get(interaction.user.id)?.nickname ?? interaction.user.username;
		const player: PlayerData = {
			userId,
			username: displayName,
			stats,
			proofUrl,
			verified: false,
			submittedAt: new Date(),
		};

		// adiciona ou atualiza player
		const existingIndex = players.findIndex(p => p.userId === userId);
		if (existingIndex !== -1) {
			players[existingIndex] = player;
		} else {
			players.push(player);
		}

		// salva no JSON
		savePlayers(players);

		await interaction.reply({
			content: '✅ Sua submissão foi enviada e aguarda verificação!',
			ephemeral: true,
		});

		// enviar para canal de verificação
		const channel = interaction.client.channels.cache.get(VERIFICATION_CHANNEL_ID) as TextChannel;
		if (!channel) return;

		const row = new ActionRowBuilder<ButtonBuilder>()
			.addComponents(
				new ButtonBuilder()
					.setCustomId(`approve_${userId}`)
					.setLabel('✅ Aprovar')
					.setStyle(ButtonStyle.Success),
				new ButtonBuilder()
					.setCustomId(`reject_${userId}`)
					.setLabel('❌ Rejeitar')
					.setStyle(ButtonStyle.Danger)
			);

		await channel.send({
			content: `Nova submissão de **${interaction.user.username}**`,
			embeds: [
				{
					title: 'Stats da conta',
					fields: [
						{ name: 'Level', value: `${stats.level}`, inline: true },
						{ name: 'Melee', value: `${stats.melee}`, inline: true },
						{ name: 'Pally', value: `${stats.pally}`, inline: true },
						{ name: 'Mage', value: `${stats.mage}`, inline: true },
						{ name: 'Defense', value: `${stats.defense}`, inline: true },
					],
					image: { url: proofUrl },
				},
			],
			components: [row],
		});
	},
};





