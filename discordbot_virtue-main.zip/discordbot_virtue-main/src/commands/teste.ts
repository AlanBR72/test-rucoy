import { ChatInputCommandInteraction, SlashCommandBuilder } from 'discord.js';



const ALLOWED_ROLE_IDS = [
  '1207024850925912115', // dev
  //'1207026614119039087', // virtue
];


export default {
  data: new SlashCommandBuilder()
    .setName('teste')                  // nome do comando
    .setDescription('Commando de Teste'),// descrição do comando

    
  async execute(interaction: ChatInputCommandInteraction) {
        
    // Verifica permissões
		const member = interaction.guild?.members.cache.get(interaction.user.id);
		if (!member) return;

		const hasRole = member.roles.cache.some(role => ALLOWED_ROLE_IDS.includes(role.id));
		if (!hasRole) {
			await interaction.reply({
				content: '❌ Você não tem permissão para usar este comando.',
				ephemeral: true
			});
			return;
		}

    await interaction.reply({
        content: "Teste Efetuado" ,        
        ephemeral: true
    });  
}
}


