import { ActionRowBuilder, ButtonBuilder, ButtonInteraction, ButtonStyle, ChatInputCommandInteraction, EmbedBuilder, SlashCommandBuilder } from 'discord.js';
import { players } from '../data/players.js';

export default {
  data: new SlashCommandBuilder()
    .setName('viewallrank')
    .setDescription('Mostra todos os rankings da guild com paginação'),
    

  async execute(interaction: ChatInputCommandInteraction) {
    const verifiedPlayers = players.filter(p => p.verified);

    if (verifiedPlayers.length === 0) {
      await interaction.reply({ content: 'Nenhuma submissão verificada encontrada.', ephemeral: true });
      return;
    }

    const categories: (keyof typeof players[0]['stats'])[] = ['level', 'melee', 'pally', 'mage', 'defense'];
    let page = 0;

    const generateEmbed = () => {
      const category = categories[page];
      const topPlayers = [...verifiedPlayers]
        .sort((a, b) => b.stats[category] - a.stats[category])
        .slice(0, 25);

      return new EmbedBuilder()
        .setTitle(`🏆 Top 25 - ${category.charAt(0).toUpperCase() + category.slice(1)}`)
        .setColor(0x00ff00)
        .setDescription(
          topPlayers.map((p, i) => `${i + 1}. **${p.username}** - ${p.stats[category]}`).join('\n')
        )
        .setFooter({ text: `Categoria ${page + 1} de ${categories.length}` })
        .setTimestamp();
    };

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder().setCustomId('prev').setLabel('⬅️ Anterior').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('next').setLabel('➡️ Próximo').setStyle(ButtonStyle.Primary)
    );

    const msg = await interaction.reply({ 
       embeds: [generateEmbed()],
       components: [row], 
       fetchReply: true, 
       ephemeral: true});

    // Collector para os botões
    const collector = msg.createMessageComponentCollector({ time: 60000 }); // 1 min

    collector.on('collect', (btn: ButtonInteraction) => {
      if (!btn.isButton()) return;

      if (btn.customId === 'next') {
        page = (page + 1) % categories.length;
      } else if (btn.customId === 'prev') {
        page = (page - 1 + categories.length) % categories.length;
      }

      btn.update({ embeds: [generateEmbed()] });
    });

    collector.on('end', () => {
      // remove botões quando expirar
      msg.edit({ components: [] }).catch(() => {});
    });
  }
};
