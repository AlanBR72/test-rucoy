import { ChatInputCommandInteraction, EmbedBuilder, SlashCommandBuilder } from 'discord.js';
import { players } from '../data/players.js';

export default {
  data: new SlashCommandBuilder()
    .setName('viewrank')
    .setDescription('Mostra o ranking das contas')
    .addStringOption(opt =>
      opt.setName('categoria')
         .setDescription('Escolha a categoria')
         .setRequired(true)
         .addChoices(
            { name: 'Level', value: 'level' },
            { name: 'Melee', value: 'melee' },
            { name: 'Pally', value: 'pally' },
            { name: 'Mage', value: 'mage' },
            { name: 'Defense', value: 'defense' }
         )
    ),

  async execute(interaction: ChatInputCommandInteraction) {
    const category = interaction.options.getString('categoria', true) as keyof typeof players[0]['stats'];

    // Filtra apenas players verificados, se quiser
    const verifiedPlayers = players.filter(p => p.verified);

    // Ordena decrescente e pega top 25
    const topPlayers = [...verifiedPlayers]
      .sort((a, b) => b.stats[category] - a.stats[category])
      .slice(0, 25);

    if (topPlayers.length === 0) {
      await interaction.reply({ content: 'Nenhuma submissão encontrada para esta categoria.', ephemeral: true });
      return;
    }

    // Monta o embed
    const embed = new EmbedBuilder()
      .setTitle(`🏆 Top 25 - ${category.charAt(0).toUpperCase() + category.slice(1)}`)
      .setColor(0x00ff00)
      .setDescription(
        topPlayers.map((p, index) => `${index + 1}. **${p.username}** - ${category}: ${p.stats[category]}`).join('\n')
      );

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};


