import 'dotenv/config';
import process from 'node:process';

export const config = {
	token: process.env.DISCORD_TOKEN!,
	clientId: process.env.CLIENT_ID!,
	guildId: process.env.GUILD_ID ?? null,

	env: process.env.NODE_ENV ?? 'development',
};
