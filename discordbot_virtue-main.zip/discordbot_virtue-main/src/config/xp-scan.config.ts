export const XP_SCAN_CONFIG = {
  start: {
    year: 2016,
    month: 1,
  },
  end: {
    year: 2025,
    month: 12,
  },

  // se true: pega apenas Janeiro de cada ano (ex: 2016-01, 2017-01)
  firstMonthEachYear: true,

  // se true: executa a rotina `xp-first` quando o bot ficar pronto
  runOnStartup: true,

  // log detalhado para xp-first
  verboseFirstScan: true,
  logFile: "src/data/xp-first.log",

  delayMs: 10_000, // 10 segundos entre requests
};
