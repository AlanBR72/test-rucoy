import { loadPlayers } from './storage.js';

export interface PlayerData {
  userId: string;
  username: string;
  stats: {
    level: number;
    melee: number;
    pally: number;
    mage: number;
    defense: number;
  };
  proofUrl: string;
  verified: boolean;
  submittedAt: Date;
}

// Carrega do JSON
export const players: PlayerData[] = loadPlayers();
