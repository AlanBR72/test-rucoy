import fs from 'node:fs';
import { PlayerData } from './players.js';

export const PLAYERS_JSON_PATH = new URL('./players.json', import.meta.url);

export function loadPlayers(): PlayerData[] {
  if (!fs.existsSync(PLAYERS_JSON_PATH)) return [];
  const data = fs.readFileSync(PLAYERS_JSON_PATH, 'utf-8');
  return JSON.parse(data, (key, value) => {
    // transforma strings de data em Date
    if (key === 'submittedAt') return new Date(value);
    return value;
  });
}

export function savePlayers(players: PlayerData[]) {
  fs.writeFileSync(PLAYERS_JSON_PATH, JSON.stringify(players, null, 2));
}
