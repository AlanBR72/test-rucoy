import { Events, Interaction } from 'discord.js';
import { players } from '../data/players.js';
import { savePlayers } from '../data/storage.js';
import { updateRankMessage } from '../util/rankUpdater.js';

export default {
  name: Events.InteractionCreate,

  async execute(interaction: Interaction) {
    // 1️⃣ Slash command
    if (interaction.isChatInputCommand()) {
      const command = interaction.client.commands.get(interaction.commandName);
      if (!command) return;

      try {
        await command.execute(interaction);
      } catch (error) {
        console.error(error);
        await interaction.reply({
          content: '❌ Erro ao executar o comando.',
          ephemeral: true,
        });
      }
      return; // já processou, sai do evento
    }

    // 2️⃣ Botões
    if (interaction.isButton()) {
      const [action, userId] = interaction.customId.split('_');
      const player = players.find(p => p.userId === userId);
      if (!player) return;

      if (action === 'approve') {
        player.verified = true;
        await interaction.update({ content: `✅ ${player.username} aprovado!`, components: [] });
      } else if (action === 'reject') {
        player.verified = false;
        await interaction.update({ content: `❌ ${player.username} rejeitado!`, components: [] });
      }

      // 3️⃣ Salva no JSON
      savePlayers(players);

      // 4️⃣ Atualiza o rank fixo
      await updateRankMessage(interaction.client);

      return;
    }
  },
};
