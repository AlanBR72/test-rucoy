import { Events, Message, TextChannel } from 'discord.js';

export default {
  name: Events.MessageCreate,
  async execute(message: Message) {
    if (message.author.bot) return; // ignora o próprio bot

    if (message.channel instanceof TextChannel) {
      if (message.content === 'Lping') {
        console.log(`Mensagem recebida: ${message.content}`);
        await message.channel.send('Pong!');
      }
    }
  },
};
