import { Client, Events } from 'discord.js';

export default {
	name: Events.ClientReady, // ✅ clientReady
	once: true,
	execute(client: Client) {
		console.log(`✅ Bot logado como ${client.user?.tag}`);
	},


};

