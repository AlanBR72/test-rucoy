import { Client, Collection, GatewayIntentBits } from 'discord.js';
import 'dotenv/config';
import { initializeRankMessage } from '../src/util/rankUpdater.js';
import { config } from './config.js';
// import { XP_SCAN_CONFIG } from './config/xp-scan.config.js';
// import { runXpFirstScan } from './jobs/xp-first.job.js';
import { deployCommands } from './util/deployCommands.js';
import { loadCommands } from './util/loadCommands.js';
import { loadEvents } from './util/loadEvents.js';

// Criando o client o bot
const client = new Client({
	intents: [GatewayIntentBits.Guilds],
});

// coleção de comandos
client.commands = new Collection();

// 🔥 REGISTRA COMANDOS NO DISCORD (DEV)
await deployCommands();

// carrega comandos na memória
const commands = await loadCommands(new URL('./commands/', import.meta.url));
for (const command of commands) {
	client.commands.set(command.data.name, command);
}

// carrega eventos
const events = await loadEvents(new URL('./events/', import.meta.url));
for (const event of events) {
	client[event.once ? 'once' : 'on'](event.name, (...args) =>
		event.execute(...args)
	);
}

// Login do Do bot, e informa algumas informaçoes
await client.login(config.token);
client.once('ready', async () => {
	console.log(`✅ Bot logado como ${client.user!.tag}`);
	await initializeRankMessage(client);

	/* inicia xp-first se configurado
	try {
		if (XP_SCAN_CONFIG.runOnStartup) {
			console.log('🚀 XP FIRST: iniciando varredura automática (startup)');
			runXpFirstScan().catch(err => console.error('Erro em xp-first startup:', err));
		}
	} catch (err) {
		console.error('Erro ao iniciar xp-first:', err);
	}

	*/

});

