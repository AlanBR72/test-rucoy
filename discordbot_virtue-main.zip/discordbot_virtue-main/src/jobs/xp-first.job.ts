import { appendFile, mkdir, writeFile } from "fs/promises";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { XP_SCAN_CONFIG } from "../config/xp-scan.config.js";
import { fetchXpTop } from "../services/rucoy/xpTop.service.js";
import { generateFirstMonthOfEachYear } from "../util/monthRange.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const OUTPUT_PATH = join(__dirname, "..", "data", "xp-first.json");
const LOG_PATH = join(__dirname, "..", "data", "xp-first.log");

async function sleep(ms: number) {
    return new Promise((res) => setTimeout(res, ms));
}

async function appendLog(line: string) {
    const tsLine = `${new Date().toISOString()} ${line}\n`;
    await appendFile(LOG_PATH, tsLine, "utf8");
}

export async function runXpFirstScan(delayMs?: number) {
    const ms = delayMs ?? XP_SCAN_CONFIG.delayMs ?? 5000;
    const verbose = XP_SCAN_CONFIG.verboseFirstScan ?? true;

    const months = generateFirstMonthOfEachYear(XP_SCAN_CONFIG.start, XP_SCAN_CONFIG.end);

    // ensure dir exists
    await mkdir(dirname(OUTPUT_PATH), { recursive: true });

    // header log
    if (verbose) {
        await writeFile(LOG_PATH, `=== XP FIRST SCAN STARTED ${new Date().toISOString()} ===\n`, "utf8");
        await appendLog(`Config: start=${XP_SCAN_CONFIG.start.year}-${String(XP_SCAN_CONFIG.start.month).padStart(2, '0')} end=${XP_SCAN_CONFIG.end.year}-${String(XP_SCAN_CONFIG.end.month).padStart(2, '0')} delayMs=${ms}`);
        await appendLog(`Months to process: ${months.map(m => `${m.year}-${String(m.month).padStart(2, '0')}`).join(', ')}`);
    }

    console.log("════════════════════════════════════");
    console.log("📦 INICIANDO XP FIRST SCAN (Janeiro de cada ano)");
    console.log(`🗓️ Meses a processar: ${months.map(m => `${m.year}-${String(m.month).padStart(2, '0')}`).join(', ')}`);
    console.log("════════════════════════════════════");

    // carregar snapshot anterior para detectar perdas
    let previous: Record<string, number> = {};
    try {
        const prevRaw = await import(OUTPUT_PATH + "?cacheBust=" + Date.now());
        // import retorna um módulo; com json node flag, but to be robust we'll try read file as text fallback
        previous = prevRaw.default ?? {};
    } catch {
        // fallback: tentar ler file como texto
        try {
            const prevText = await (await import('fs/promises')).readFile(OUTPUT_PATH, 'utf8');
            previous = prevText ? JSON.parse(prevText) : {};
        } catch {
            previous = {};
        }
    }

    const aggregated: Record<string, number> = {};
    let overwrittenCount = 0;
    const overwrites: string[] = [];

    // importar helper de mob-history
    const { appendMobEvent } = await import('../storage/mob-history.store.js');

    for (const { year, month } of months) {
        const label = `${year}-${String(month).padStart(2, "0")}`;
        console.log(`🔎 Buscando TOP XP: ${label}`);
        if (verbose) await appendLog(`-- START MONTH ${label}`);

        try {
            const top = await fetchXpTop(year, month);
            if (top.length === 0) {
                console.warn(`⚠️ Nenhum player encontrado em ${label}`);
                if (verbose) await appendLog(`⚠️ Nenhum player encontrado em ${label}`);
                continue;
            }

            for (const entry of top) {
                const prev = aggregated[entry.name];
                if (prev !== undefined) {
                    overwrittenCount++;
                    overwrites.push(`${entry.name}: ${prev} -> ${entry.xp} (${label})`);
                    if (verbose) await appendLog(`OVERWRITE ${entry.name}: ${prev} -> ${entry.xp} (${label})`);
                } else {
                    if (verbose) await appendLog(`ADD ${entry.name}: ${entry.xp} (${label})`);
                }
                // sobrescreve caso mesmo nome apareça em anos diferentes — o último ano prevalece
                aggregated[entry.name] = entry.xp;
            }

            console.log(`✅ ${label} processado — ${top.length} entradas`);
            if (verbose) await appendLog(`✅ ${label} processado — ${top.length} entradas`);

            await sleep(ms);
        } catch (err) {
            console.error(`❌ Erro ao processar ${label}`, err);
            if (verbose) await appendLog(`❌ Erro ao processar ${label}: ${String(err)}`);
        }

        if (verbose) await appendLog(`-- END MONTH ${label}`);
    }

    // detectar quem perdeu XP comparando aggregated com previous
    let mobCount = 0;
    for (const [name, newXp] of Object.entries(aggregated)) {
        const prevXp = previous[name];
        if (prevXp !== undefined && newXp < prevXp) {
            const lost = prevXp - newXp;
            mobCount++;
            await appendLog(`MOB DETECTED ${name}: ${prevXp} -> ${newXp} (lost ${lost})`);
            await appendMobEvent(name, prevXp, newXp);
        }
    }

    // salvar somente nomes e xp
    await writeFile(OUTPUT_PATH, JSON.stringify(aggregated, null, 2), "utf8");
    console.log(`💾 Arquivo salvo em ${OUTPUT_PATH} com ${Object.keys(aggregated).length} contas`);

    if (verbose) {
        await appendLog(`Resultado final: ${Object.keys(aggregated).length} contas`);
        await appendLog(`Overwrites: ${overwrittenCount}`);
        if (overwrites.length) {
            await appendLog(`Overwrites details:`);
            for (const o of overwrites) await appendLog(`  ${o}`);
        }
        await appendLog(`MOB events detected: ${mobCount}`);
        await appendLog(`=== XP FIRST SCAN FINISHED ${new Date().toISOString()} ===\n`);
    }
    if (verbose) {
        await appendLog(`Resultado final: ${Object.keys(aggregated).length} contas`);
        await appendLog(`Overwrites: ${overwrittenCount}`);
        if (overwrites.length) {
            await appendLog(`Overwrites details:`);
            for (const o of overwrites) await appendLog(`  ${o}`);
        }
        await appendLog(`=== XP FIRST SCAN FINISHED ${new Date().toISOString()} ===\n`);
    }
}

// se executado diretamente via `bun run` (fallback robusto)
import { basename } from 'path';
if (basename(process.argv[1] ?? '') === 'xp-first.job.ts') {
    console.log('📌 Executando xp-first job diretamente (manual run)');
    // usando delay menor ao rodar manualmente para testes rápidos
    runXpFirstScan(2000).catch(err => console.error(err));
}
