import { XP_SCAN_CONFIG } from "../config/xp-scan.config.js";
import { generateMonthRange } from "../util/monthRange.js";
import { fetchXpTop } from "../services/rucoy/xpTop.service.js";
import { saveXp } from "../storage/xp-history.store.js";
import {transformXp} from "../util/players_consolidated.js";
function sleep(ms: number) {
  return new Promise(res => setTimeout(res, ms));
}

export async function runXpHistoryScan() {
  const months = generateMonthRange(
    XP_SCAN_CONFIG.start,
    XP_SCAN_CONFIG.end
  );

  console.log("════════════════════════════════════");
  console.log("📦 INICIANDO XP HISTORY SCAN");
  console.log(`🗓️ Período: ${XP_SCAN_CONFIG.start.year}-${String(XP_SCAN_CONFIG.start.month).padStart(2, "0")} → ${XP_SCAN_CONFIG.end.year}-${String(XP_SCAN_CONFIG.end.month).padStart(2, "0")}`);
  console.log(`⏱️ Delay: ${XP_SCAN_CONFIG.delayMs}ms`);
  console.log(`📊 Total de meses: ${months.length}`);
  console.log("════════════════════════════════════");

  let monthIndex = 0;

  for (const { year, month } of months) {
    monthIndex++;
    const label = `${year}-${String(month).padStart(2, "0")}`;
    const startTime = Date.now();

    console.log("");
    console.log(`🔎 [${monthIndex}/${months.length}] Escaneando TOP XP: ${label}`);

    try {
      const top = await fetchXpTop(year, month);

      if (top.length === 0) {
        console.warn(`⚠️ Nenhum player encontrado em ${label}`);
        continue;
      }

      let saved = 0;

      for (const entry of top) {
        saveXp(entry.name, year, month, entry.xp);
        saved++;
      }

      const duration = Date.now() - startTime;

      const topPlayer = top[0];
      const lastPlayer = top[top.length - 1];

      console.log(`✅ Mês ${label} finalizado`);
      console.log(`👥 Players salvos: ${saved}`);
      console.log(`🥇 Top 1: ${topPlayer.name} (${topPlayer.xp.toLocaleString()} XP)`);
      console.log(`🐢 Último: ${lastPlayer.name} (${lastPlayer.xp.toLocaleString()} XP)`);
      console.log(`⏱️ Tempo: ${duration}ms`);

      await sleep(XP_SCAN_CONFIG.delayMs);
    } catch (err) {
      console.error(`❌ ERRO ao processar ${label}`);
      console.error(err);
    }
  }
  transformXp();
  console.log("");
  console.log("════════════════════════════════════");
  console.log("🏁 XP HISTORY SCAN FINALIZADO");
  console.log("════════════════════════════════════");
  
}
