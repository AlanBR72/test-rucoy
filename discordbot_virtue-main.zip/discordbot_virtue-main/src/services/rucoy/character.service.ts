export interface RucoyCharacter {
  name: string;
  level: number;
  guild?: {
    name: string;
    url: string;
  };
  title?: {
    name: string;
    rarity?: string;
  };
  online: boolean;
  supporter: boolean;
  born?: string;
  lastOnline?: string;
  recentActivity: string[];
}

export async function fetchCharacter(
  characterName: string
): Promise<RucoyCharacter> {
  const url = `https://www.rucoyonline.com/characters/${encodeURIComponent(
    characterName
  )}`;

  const res = await fetch(url);
  if (!res.ok) throw new Error("Character not found");

  const html = await res.text();

  // ===== helpers simples =====
  const extract = (regex: RegExp) =>
    regex.exec(html)?.[1]?.trim();

  const has = (text: string) => html.includes(text);

  // ===== dados principais =====
  const name = extract(/<td>Name<\/td>\s*<td>(.*?)<\/td>/)!;
  const level = Number(
    extract(/<td>Level<\/td>\s*<td>(\d+)<\/td>/)
  );

  const guildMatch = html.match(
    /<td>Guild<\/td>\s*<td><a href="(.*?)">(.*?)<\/a><\/td>/
  );

  const titleMatch = html.match(
    /<td>Title<\/td>[\s\S]*?<td>\s*(.*?)\s*<span.*?>(.*?)<\/span>/
  );

  const born = extract(/<td>Born<\/td>\s*<td>(.*?)<\/td>/);
  const lastOnline = extract(
    /<td>Last online<\/td>\s*<td>\s*(.*?)\s*<\/td>/
  );

  // ===== online / supporter =====
  const online = has("label-success");
  const supporter = has("label-primary");

  // ===== recent activity =====
  const activityMatches = [
    ...html.matchAll(
      /<tbody>[\s\S]*?<tr>\s*<td>([\s\S]*?)<\/td>\s*<\/tr>/g
    ),
  ];

  const recentActivity = activityMatches
    .map(m =>
      m[1]
        .replace(/<[^>]+>/g, "")
        .replace(/\s+/g, " ")
        .trim()
    )
    .filter(t => t.includes("killed"))
    .slice(0, 10); // limite seguro

  return {
    name,
    level,
    guild: guildMatch
      ? { name: guildMatch[2], url: guildMatch[1] }
      : undefined,
    title: titleMatch
      ? { name: titleMatch[1], rarity: titleMatch[2] }
      : undefined,
    online,
    supporter,
    born,
    lastOnline,
    recentActivity,
  };
}
