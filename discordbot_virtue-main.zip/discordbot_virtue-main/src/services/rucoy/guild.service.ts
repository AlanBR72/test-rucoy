import axios from "axios";
import * as cheerio from "cheerio";
import type { GuildMember } from "./rucoy.types.js";

export async function fetchGuildMembers(
  guildName: string
): Promise<GuildMember[]> {
  const url = `https://www.rucoyonline.com/guild/${encodeURIComponent(guildName)}`;

  const { data } = await axios.get(url, {
    headers: {
      "User-Agent": "Mozilla/5.0",
    },
  });

  const $ = cheerio.load(data);
  const members: GuildMember[] = [];

  $("table.table tbody tr").each((_, tr) => {
    const tds = $(tr).find("td");
    if (tds.length !== 3) return;

    const nameTd = $(tds[0]);

    const name = nameTd.find("a").text().trim();
    const profileHref = nameTd.find("a").attr("href");

    const online =
      nameTd.find("span:contains('Online')").length > 0;
    const supporter =
      nameTd.find("span:contains('Supporter')").length > 0;
    const leader = nameTd.text().includes("(Leader)");

    const level = Number($(tds[1]).text().trim());
    const joinDate = $(tds[2]).text().trim();

    members.push({
      name,
      level,
      joinDate,
      online,
      supporter,
      leader,
      profileUrl: profileHref
        ? `https://www.rucoyonline.com${profileHref}`
        : null,
    });
  });

  return members;
}
