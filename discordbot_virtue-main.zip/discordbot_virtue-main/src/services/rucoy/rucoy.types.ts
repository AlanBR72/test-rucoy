export interface GuildMember {
    name: string;
    level: number;
    joinDate: string;
    online: boolean;
    supporter: boolean;
    leader: boolean;
    profileUrl: string | null;
}
