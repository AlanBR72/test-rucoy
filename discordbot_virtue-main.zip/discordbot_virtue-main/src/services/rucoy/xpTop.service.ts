import { JSDOM } from "jsdom";

export interface XpTopEntry {
  name: string;
  xp: number;
}

export async function fetchXpTop(
  year: number,
  month: number
): Promise<XpTopEntry[]> {
  const url = `https://www.rucoyonline.com/highscores/experience/${year}/${month}`;

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Erro ao buscar TOP XP ${year}-${month}`);
  }

  const html = await res.text();
  const dom = new JSDOM(html);
  const document = dom.window.document;

  const rows = document.querySelectorAll(
    "table.table-highscores tbody tr"
  );

  const result: XpTopEntry[] = [];

  for (const row of rows) {
    const tds = row.querySelectorAll("td");
    if (tds.length < 4) continue;

    const nameAnchor = tds[1].querySelector("a");
    if (!nameAnchor) continue;

    const name = nameAnchor.textContent!.trim();

    // ✅ EXPERIENCE (não level)
    const xpText = tds[3].textContent!
      .replace(/,/g, "")
      .trim();

    const xp = Number(xpText);
    if (Number.isNaN(xp)) continue;

    result.push({ name, xp });
  }

  return result;
}
