import { TextChannel, EmbedBuilder } from "discord.js";
import { fetchGuildMembers } from "../services/rucoy/guild.service.js";
import { fetchCharacter } from "../services/rucoy/character.service.js";
import { guildState } from "./guild.state.js";

function spyLog(msg: string) {
  const time = new Date().toLocaleTimeString("pt-BR");
  console.log(`[GUILD SPY ${time}] ${msg}`);
}

export async function startGuildSpy(
  guildName: string,
  channel: TextChannel
) {
  spyLog(`Spy iniciado para guild ${guildName}`);

  setInterval(async () => {
    try {
      spyLog("Checagem iniciada");

      const members = await fetchGuildMembers(guildName);

      for (const member of members) {
        const char = await fetchCharacter(member.name);
        const prev = guildState.get(char.name);

        // 🔴 IGNORA OFFLINE
        if (!char.online) {
          continue;
        }

        // 🟢 OFF → ONLINE (primeira vez ou retorno)
        if (!prev) {
          guildState.set(char.name, {
            level: char.level,
            online: true,
          });

          spyLog(`${char.name} ficou ONLINE`);

          await channel.send({
            embeds: [
              new EmbedBuilder()
                .setTitle("🟢 Player Online")
                .setDescription(`👤 ${char.name}`)
                .setColor(0x00ff00)
                .addFields(
                  { name: "Level", value: String(char.level), inline: true },
                  { name: "Guild", value: guildName, inline: true }
                )
            ]
          });

          continue;
        }

        // 🧠 Já está online e sendo monitorado
        // nada a fazer → sem flood
      }

      spyLog("Checagem finalizada");

    } catch (err) {
      console.error("[GUILD SPY] Erro:", err);
    }
  }, 1000 * 60 * 5); // 5 minutos
}
