export interface SpyCharacterState {
  level: number;
  online: boolean;
  lastActivityHash?: string;
}

export const guildState = new Map<string, SpyCharacterState>();
