import { mkdir, readFile, writeFile } from 'fs/promises';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const FILE_PATH = join(__dirname, '..', 'data', 'mob-history.json');

export interface MobEvent {
    date: string;
    lost: number;
    before: number;
    after: number;
}

export type MobHistory = Record<string, MobEvent[]>;

async function ensureDir() {
    await mkdir(dirname(FILE_PATH), { recursive: true });
}

export async function loadMobHistory(): Promise<MobHistory> {
    try {
        const raw = await readFile(FILE_PATH, 'utf8');
        return raw ? JSON.parse(raw) : {};
    } catch {
        return {};
    }
}

export async function saveMobHistory(data: MobHistory) {
    await ensureDir();
    await writeFile(FILE_PATH, JSON.stringify(data, null, 2), 'utf8');
}

export async function appendMobEvent(name: string, before: number, after: number, date = new Date().toISOString()) {
    const lost = before - after;
    if (lost <= 0) return; // não registrar se não houve perda

    const data = await loadMobHistory();
    if (!data[name]) data[name] = [];
    data[name].push({ date, lost, before, after });
    await saveMobHistory(data);
}

export async function getRecentMobEvents(limit = 50) {
    const data = await loadMobHistory();
    const entries: Array<{ name: string; event: MobEvent }> = [];
    for (const [name, events] of Object.entries(data)) {
        for (const e of events) {
            entries.push({ name, event: e });
        }
    }
    // ordena por data desc
    entries.sort((a, b) => (a.event.date < b.event.date ? 1 : -1));
    return entries.slice(0, limit);
}