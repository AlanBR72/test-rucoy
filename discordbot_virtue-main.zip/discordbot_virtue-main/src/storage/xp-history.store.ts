import fs from "fs";
import path from "path";

const DATA_PATH = path.resolve("src/data/xp-history.json");

type XpEntry = {
  date: string;
  xp: number;
};

type XpHistory = Record<string, XpEntry[]>;

function loadFile(): XpHistory {
  if (!fs.existsSync(DATA_PATH)) {
    return {};
  }

  const raw = fs.readFileSync(DATA_PATH, "utf-8");
  return raw ? JSON.parse(raw) : {};
}

function saveFile(data: XpHistory) {
  fs.writeFileSync(DATA_PATH, JSON.stringify(data, null, 2));
}

export function saveXp(
  nick: string,
  year: number,
  month: number,
  xp: number
) {
  const data = loadFile();
  const date = `${year}-${String(month).padStart(2, "0")}`;

  if (!data[nick]) {
    data[nick] = [];
  }

  const exists = data[nick].some(e => e.date === date);
  if (exists) return;

  data[nick].push({ date, xp });
  saveFile(data);
}
