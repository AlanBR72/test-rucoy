import 'dotenv/config';
import { REST, Routes } from 'discord.js';
import { config } from '../config.js';

const rest = new REST({ version: '10' }).setToken(config.token);

await rest.put(
	Routes.applicationGuildCommands(
		config.clientId,
		config.guildId!
	),
	{ body: [] }
);

console.log('🧹 Comandos apagados');
