import { REST, Routes } from 'discord.js';
import { config } from '../config.js';
import { loadCommands } from './loadCommands.js';

export async function deployCommands() {
	
	const rest = new REST({ version: '10' }).setToken(config.token);

	const commands = await loadCommands(
		new URL('../commands/', import.meta.url)
	);

	const data = commands.map(cmd => cmd.data.toJSON());

	await rest.put(
		Routes.applicationGuildCommands(
			config.clientId,
			config.guildId!
		),
		{ body: data }
	);

	console.log(`🚀 ${data.length} comandos registrados`);
}
