import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export async function loadCommands(dir: URL) {
	const commands = [];

	// ✅ converte URL para caminho real do sistema (Windows-safe)
	const dirPath = fileURLToPath(dir);

	const files = fs.readdirSync(dirPath);

	for (const file of files) {
		if (!file.endsWith('.js') && !file.endsWith('.ts')) continue;

		const fullPath = path.join(dirPath, file);

		const command = (await import(
			pathToFileURL(fullPath).href
		)).default;

		commands.push(command);
	}

	return commands;
}
