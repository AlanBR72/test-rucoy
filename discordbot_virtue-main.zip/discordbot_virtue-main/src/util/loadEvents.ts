import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

export async function loadEvents(dir: URL) {
	const events = [];

	// ✅ converte URL para path real do sistema
	const dirPath = fileURLToPath(dir);

	const files = fs.readdirSync(dirPath);

	for (const file of files) {
		if (!file.endsWith('.js') && !file.endsWith('.ts')) continue;

		// ✅ usa SEMPRE dirPath
		const filePath = path.join(dirPath, file);

		const event = (await import(
			pathToFileURL(filePath).href
		)).default;

		events.push(event);
	}

	return events;
}
