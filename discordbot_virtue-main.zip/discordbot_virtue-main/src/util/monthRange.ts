type MonthRef = {
  year: number;
  month: number;
};

export function generateMonthRange(
  start: MonthRef,
  end: MonthRef
): MonthRef[] {
  const result: MonthRef[] = [];

  let y = start.year;
  let m = start.month;

  while (y < end.year || (y === end.year && m <= end.month)) {
    result.push({ year: y, month: m });

    m++;
    if (m > 12) {
      m = 1;
      y++;
    }
  }

  return result;
}

// Retorna apenas Janeiro (month = 1) de cada ano no intervalo inclusivo
export function generateFirstMonthOfEachYear(
  start: MonthRef,
  end: MonthRef
): MonthRef[] {
  const result: MonthRef[] = [];

  let startYear = start.year;
  if (start.month > 1) startYear = start.year + 1; // se começou após janeiro, pula o ano inicial

  for (let y = startYear; y <= end.year; y++) {
    // garante que o ano y esteja dentro do intervalo (se end for antes de janeiro no ano final, pular)
    if (y === end.year && end.month < 1) continue; // normalmente não acontece
    result.push({ year: y, month: 1 });
  }

  return result;
}
