export function normalizeName(raw: string): string {
  return raw
    .replace(/\s+Online/i, "")
    .replace(/\s+Offline/i, "")
    .replace(/\n/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}
