import { readFile, writeFile, mkdir } from 'fs/promises';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Tipagem do JSON original
interface Record {
  date: string;
  xp: number;
}

interface XpHistory {
  [name: string]: Record[];
}

// Caminho do arquivo atual
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Caminhos dos arquivos
const inputPath = join(__dirname, '..', 'data', 'xp-history.json');
const outputPath = join(__dirname, '..', 'data', 'xp-first.json');

export async function transformXp() {
  try {
    console.log('Iniciando script...');
    console.log('Caminho de entrada:', inputPath);
    console.log('Caminho de saída:', outputPath);

    // Lendo o JSON
    const jsonString = await readFile(inputPath, 'utf8');
    console.log('Arquivo lido com sucesso. Conteúdo (primeiros 500 chars):');
    console.log(jsonString.slice(0, 500));

    const data: XpHistory = JSON.parse(jsonString);
    console.log('JSON parseado com sucesso.');
    console.log('Nomes encontrados:', Object.keys(data));

    // Transformando para manter apenas o xp do primeiro registro
    const newData: { [name: string]: number } = Object.fromEntries(
      Object.entries(data).map(([name, records]) => {
        if (!records || records.length === 0) {
          console.warn(`Atenção: ${name} não possui registros`);
          return [name, 0];
        }
        return [name, records[0].xp];
      })
    );
    console.log('Transformação concluída:', newData);

    // Garante que a pasta de saída exista
    await mkdir(dirname(outputPath), { recursive: true });

    // Salvando o novo JSON
    await writeFile(outputPath, JSON.stringify(newData, null, 2), 'utf8');
    console.log('Arquivo escrito com sucesso:', outputPath);
  } catch (err) {
    console.error('Erro ao processar o JSON:', err);
  }
}

transformXp();
