import { Client, EmbedBuilder, TextChannel } from 'discord.js';
import fs from 'node:fs';
import { players } from '../data/players.js';

const RANK_JSON_PATH = new URL('./rankMessage.json', import.meta.url);

// Função para gerar o embed do rank
export function generateRankEmbed() {
  // Filtra apenas players verificados
  const verifiedPlayers = players.filter(p => p.verified);

  // Ordena por level (ou por qualquer stat que quiser)
  const sorted = verifiedPlayers.sort((a, b) => b.stats.level - a.stats.level);

  const embed = new EmbedBuilder()
    .setTitle('🏆 Ranking da Guild')
    .setDescription('Top players por level')
    .setColor(0x00ff00);

  sorted.slice(0, 25).forEach((player, index) => {
    embed.addFields({
      name: `${index + 1}. ${player.username}`,
      value: `Level: ${player.stats.level} | Melee: ${player.stats.melee} | Pally: ${player.stats.pally} | Mage: ${player.stats.mage} | Defense: ${player.stats.defense}`,
      inline: false
    });
  });

  if (sorted.length === 0) {
    embed.setDescription('Nenhum player verificado ainda.');
  }

  return embed;
}

// Inicializa a mensagem do rank
export async function initializeRankMessage(client: Client) {
  // Canal do rank (substitua pelo ID do canal real)
  const RANK_CHANNEL_ID = '1395553997309608088';

  const channel = client.channels.cache.get(RANK_CHANNEL_ID) as TextChannel;
  if (!channel) {
    console.log('Canal do rank não encontrado.');
    return;
  }

  if (!fs.existsSync(RANK_JSON_PATH)) {
    const embed = generateRankEmbed();
    const msg = await channel.send({ embeds: [embed] });

    fs.writeFileSync(
      RANK_JSON_PATH,
      JSON.stringify({ channelId: channel.id, messageId: msg.id }, null, 2)
    );
    console.log('Mensagem do rank criada.');
  }
}

// Atualiza a mensagem do rank
export async function updateRankMessage(client: Client) {
  
  if (!fs.existsSync(RANK_JSON_PATH)) return;

  const data = JSON.parse(fs.readFileSync(RANK_JSON_PATH, 'utf-8'));
  const channel = client.channels.cache.get(data.channelId) as TextChannel;
  if (!channel) return console.log('Canal do rank não encontrado.');

  try {
    const message = await channel.messages.fetch(data.messageId);
    const embed = generateRankEmbed();
    await message.edit({ embeds: [embed] });
    console.log('Rank atualizado.');
  } catch (err) {
    console.error('Erro ao atualizar o rank:', err);
  }
}
