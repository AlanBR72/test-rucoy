import { readFile, writeFile, mkdir } from "fs/promises";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const inputPath = join(__dirname, "..", "data", "xp-first.json");  // seu arquivo atual
const outputPath = join(__dirname, "..", "data", "xp-history-full.json");

export interface HistoricalRecord {
  timestamp: string;
  xp: number;
}

export interface XpHistoryFull {
  [name: string]: HistoricalRecord[];
}

/**
 * Atualiza histórico de XP
 * Adiciona o XP atual com timestamp e retorna contas que perderam XP
 */
export async function updateXpHistory(): Promise<string[]> {
  try {
    // Lê XP atual
    const jsonString = await readFile(inputPath, "utf8");
    const currentXp: { [name: string]: number } = JSON.parse(jsonString);

    // Lê histórico antigo
    let history: XpHistoryFull = {};
    try {
      const oldHistory = await readFile(outputPath, "utf8");
      history = JSON.parse(oldHistory);
    } catch {
      console.log("Nenhum histórico antigo encontrado. Criando novo.");
    }

    const timestamp = new Date().toISOString();
    const lostXpAccounts: string[] = [];

    for (const [name, xp] of Object.entries(currentXp)) {
      if (!history[name]) history[name] = [];
      const previous = history[name][history[name].length - 1]?.xp ?? xp;
      if (xp < previous) lostXpAccounts.push(`${name} perdeu XP! Antes: ${previous}, Agora: ${xp}`);
      history[name].push({ timestamp, xp });
    }

    await mkdir(dirname(outputPath), { recursive: true });
    await writeFile(outputPath, JSON.stringify(history, null, 2), "utf8");

    return lostXpAccounts;
  } catch (err) {
    console.error("Erro ao atualizar histórico:", err);
    return [];
  }
}
